# Health Myth Buster — Grade 6 prototype

## Run it
1. Extract `Health_Myth_Buster_Website.zip`.
2. Open `index.html` in a modern web browser. No installation or account is required.
3. Enter a claim, select **Check Claim**, and read the result and source.

## Free hosting
You can host the static files for free with GitHub Pages:
1. Create a GitHub repository.
2. Upload `index.html` (and this README if desired).
3. In the repository, open Settings → Pages.
4. Choose deploy from the main branch and the root folder, then save.
5. Use the URL GitHub Pages gives you as the public project link.

## Important limitations
- This is a small educational keyword-matching prototype, not an AI medical expert.
- TRUE/FALSE/UNVERIFIED results only apply to the exact reviewed entries and should be checked against current source guidance before public use.
- UNVERIFIED means no close database match was found; it does not mean the claim is true.
- It does not collect or send the text entered by a user to a server.
- Ask a teacher or qualified health professional to review the database before demonstrating it as a health-information tool.
